// CodeCompilerController.java
package com.example.JavaCompilerUsingJavaFX&Java

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class JavaCodeCompilerController {



    @FXML
    private TextField fileNameField;

    @FXML
    private TextArea codeArea;

    @FXML
    private TextArea outputArea;

    @FXML
    private Button compileCode;


               
    // Hi dear, send me a text if the code doesn't properly. 
    // You can use the code anywhere, anyhow you want.
    // If you find this helpful, you can share a screenshot/ photo of your version of this project. I would love to see.
    // Best wishes.
    // Shakib Rahman since 2000



    
    @FXML
    private void compileCode(ActionEvent event) {
        String fileName = fileNameField.getText();
        String code = codeArea.getText();

        try {

            saveCodeToFile(fileName, code);
            compileJavaFile(fileName);


            runCompiledClass(fileName);

        } catch (IOException | InterruptedException ex) {
            ex.printStackTrace();
            outputArea.setText("Error: " + ex.getMessage());
        }
    }

    private void saveCodeToFile(String fileName, String code) throws IOException {
        try (FileWriter writer = new FileWriter(fileName + ".java")) {
            writer.write(code);
        }
    }

    private void compileJavaFile(String fileName) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        int result = compiler.run(null, null, null, fileName + ".java");
        System.out.println("Compilation result: " + (result == 0 ? "Success" : "Failure"));
    }

    private void runCompiledClass(String fileName) throws IOException, InterruptedException {

        Files.move(Path.of(fileName + ".class"), Path.of(fileName + ".class"),
                StandardCopyOption.REPLACE_EXISTING);





        long startTime = System.currentTimeMillis();

        Process process = Runtime.getRuntime().exec("java " + fileName);
        int exitCode = process.waitFor();


        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;


        String output = new String(process.getInputStream().readAllBytes());


        long memoryUsed = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

        outputArea.setText("Exit Code: " + exitCode + "\n");
        outputArea.appendText("Output:\n" + output + "\n");
        outputArea.appendText("Execution Time: " + executionTime + " ms\n");
        outputArea.appendText("Memory Used: " + memoryUsed + " bytes");
    }

   
}
